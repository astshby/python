from gevent import monkey
import rawpy
import imageio
import gevent
import os
import time
monkey.patch_all()


def deal(path):
    raw = rawpy.imread(path[0])
    rgb = raw.postprocess()
    imageio.imsave(path[1], rgb)


if __name__ == '__main__':
    path1 = 'image/'
    path2 = 'image-new/'
    path_list = os.listdir(path1)
    n = 0
    start = time.time()
    old_list = []
    new_list = []
    for i in path_list:
        portion = os.path.splitext(i)
        old = path1 + path_list[n]
        old_list.append(old)
        new = path2 + portion[0] + '.jpg'
        new_list.append(new)
        n = n + 1
    jobs = [gevent.spawn(deal, path) for path in list(zip(old_list, new_list))]
    gevent.joinall(jobs)
    end = time.time()
    print(end-start)