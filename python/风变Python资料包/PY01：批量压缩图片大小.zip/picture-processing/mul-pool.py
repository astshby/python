
from multiprocessing import Pool
import rawpy
import imageio
import os
import time


def deal(path):
    raw = rawpy.imread(path[0])
    rgb = raw.postprocess()
    imageio.imsave(path[1], rgb)
    print(path)


def task_start(path1, path2):
    path_list = os.listdir(path1)
    n = 0
    p = Pool(processes=4)
    for i in path_list:
        portion = os.path.splitext(i)
        old = path1 + path_list[n]
        new = path2 + portion[0] + '.jpg'
        p.apply_async(deal, ([old, new],))
        n = n + 1
    p.close()
    p.join()


if __name__ == '__main__':
    start = time.time()
    path1 = 'image/'
    path2 = 'image-new/'
    task_start(path1,path2)
    end = time.time()
    print(end - start)
