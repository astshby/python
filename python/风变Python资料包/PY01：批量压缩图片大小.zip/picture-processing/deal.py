# 1. Python 批量处理图片尺寸
# 1.1 任务需求：将相机中的RAW格式文件处理成1MB以内的JEPG格式
# 1.2 期望功能：创建一个文件夹python自动读取图片素材，将读取的图片压缩，导出到一个新的文件夹中，图片名称不变
# 1.3 功能显示：（1）显示图片数量与图片尺寸，突出处理前的图片为大内存文件
#               （2）跳转至编译器，华东展示编写完的代码
#               （3）运行代码，把导出的制定文件夹窗口置于桌面最上层，以缩略图显示图片导出过程
#               （4）把文件形式改为列表，展示修改后的图片尺寸
import rawpy
import imageio
import os
import time


def change(path1,path2):
    f=os.listdir(path1)
    n=0
    start=time.time()
    for i in f:
        portion=os.path.splitext(i)
        old = path1+f[n]
        raw = rawpy.imread(old)
        new = path2 + portion[0] + '.jpg'
        rgb = raw.postprocess()
        imageio.imsave(new,rgb)
        n=n+1
    end=time.time()
    print(end-start)


if __name__ == '__main__':
    change('image/','image-new/')


